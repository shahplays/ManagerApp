package com.example.mytasks.ui;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.example.mytasks.R;
import com.example.mytasks.model.Task;
import com.example.mytasks.viewmodel.TaskViewModel;

public class AddEditTaskActivity extends AppCompatActivity {

    private EditText editTitle, editDesc, editDate;
    private Spinner prioritySpinner;
    private TaskViewModel taskViewModel;
    private boolean isEdit = false;
    private Task taskToUpdate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_task);

        editTitle = findViewById(R.id.editTitle);
        editDesc = findViewById(R.id.editDescription);
        editDate = findViewById(R.id.editDate);
        prioritySpinner = findViewById(R.id.spinnerPriority);
        Button btnSave = findViewById(R.id.btnSave);

        // Spinner setup
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.priority_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        prioritySpinner.setAdapter(adapter);

        // ViewModel
        taskViewModel = new ViewModelProvider(this).get(TaskViewModel.class);

        // Check for passed data (Edit Mode)
        if (getIntent().hasExtra("task_id")) {
            isEdit = true;

            int id = getIntent().getIntExtra("task_id", -1);
            String title = getIntent().getStringExtra("task_title");
            String desc = getIntent().getStringExtra("task_description");
            String date = getIntent().getStringExtra("task_date");
            String priority = getIntent().getStringExtra("task_priority");
            boolean completed = getIntent().getBooleanExtra("task_completed", false);

            taskToUpdate = new Task(title, desc, date, priority, completed);
            taskToUpdate.setId(id);

            editTitle.setText(title);
            editDesc.setText(desc);
            editDate.setText(date);
            if (priority != null) {
                int spinnerPosition = adapter.getPosition(priority);
                prioritySpinner.setSelection(spinnerPosition);
            }
        }

        // Save Button Click
        btnSave.setOnClickListener(v -> {
            String title = editTitle.getText().toString().trim();
            String desc = editDesc.getText().toString().trim();
            String date = editDate.getText().toString().trim();
            String priority = prioritySpinner.getSelectedItem().toString();

            if (title.isEmpty() || date.isEmpty()) {
                editTitle.setError("Title required");
                editDate.setError("Date required");
                return;
            }

            Task task = new Task(title, desc, date, priority, false);
            if (isEdit) {
                task.setId(taskToUpdate.getId());
                task.setCompleted(taskToUpdate.isCompleted());
                taskViewModel.update(task);
            } else {
                taskViewModel.insert(task);
            }
            finish();
        });
    }
}
