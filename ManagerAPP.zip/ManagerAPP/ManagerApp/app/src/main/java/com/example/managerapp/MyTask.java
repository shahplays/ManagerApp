package com.example.mytasks;

import android.graphics.Paint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DiffUtil;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

public class TaskAdapter extends ListAdapter<Task, TaskAdapter.TaskViewHolder> {

    public interface OnItemClickListener {
        void onEdit(Task task);
        void onDelete(Task task);
        void onCompleteChanged(Task task, boolean isCompleted);
    }

    private OnItemClickListener listener;

    public TaskAdapter() {
        super(DIFF_CALLBACK);
    }

    private static final DiffUtil.ItemCallback<Task> DIFF_CALLBACK = new DiffUtil.ItemCallback<Task>() {
        @Override
        public boolean areItemsTheSame(@NonNull Task oldItem, @NonNull Task newItem) {
            return oldItem.getId() == newItem.getId();
        }

        @Override
        public boolean areContentsTheSame(@NonNull Task oldItem, @NonNull Task newItem) {
            return oldItem.equals(newItem);
        }
    };

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public TaskViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_task, parent, false);
        return new TaskViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull TaskViewHolder holder, int position) {
        Task task = getItem(position);
        holder.bind(task);
    }

    class TaskViewHolder extends RecyclerView.ViewHolder {
        private TextView textTitle, textDate, textPriority;
        private CheckBox checkBox;
        private ImageButton btnEdit, btnDelete;

        TaskViewHolder(View itemView) {
            super(itemView);
            textTitle = itemView.findViewById(R.id.textTitle);
            textDate = itemView.findViewById(R.id.textDate);
            textPriority = itemView.findViewById(R.id.textPriority);
            checkBox = itemView.findViewById(R.id.checkBoxComplete);
            btnEdit = itemView.findViewById(R.id.btnEdit);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }

        void bind(Task task) {
            textTitle.setText(task.getTitle());
            textDate.setText("Due: " + task.getDate());
            textPriority.setText("Priority: " + task.getPriority());
            checkBox.setChecked(task.isCompleted());

            // Strike-through if completed
            textTitle.setPaintFlags(
                    task.isCompleted() ?
                            textTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG :
                            textTitle.getPaintFlags() & ~Paint.STRIKE_THRU_TEXT_FLAG
            );

            checkBox.setOnCheckedChangeListener((btn, isChecked) -> {
                if (listener != null && getAdapterPosition() != RecyclerView.NO_POSITION) {
                    listener.onCompleteChanged(task, isChecked);
                }
            });

            btnEdit.setOnClickListener(v -> {
                if (listener != null && getAdapterPosition() != RecyclerView.NO_POSITION) {
                    listener.onEdit(task);
                }
            });

            btnDelete.setOnClickListener(v -> {
                if (listener != null && getAdapterPosition() != RecyclerView.NO_POSITION) {
                    listener.onDelete(task);
                }
            });
        }
    }
}
