package com.example.managerapp;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.util.Objects;

@Entity(tableName = "task_table")
public class Task {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String title;
    private String description;
    private String date;
    private String priority;
    private boolean completed;

    // Constructor
    public Task(String title, String description, String date, String priority, boolean completed) {
        this.title = title;
        this.description = description;
        this.date = date;
        this.priority = priority;
        this.completed = completed;
    }

    // Getters & Setters
    public int getId() { return id; }

    public void setId(int id) { this.id = id; }

    public String getTitle() { return title; }

    public String getDescription() { return description; }

    public String getDate() { return date; }

    public String getPriority() { return priority; }

    public boolean isCompleted() { return completed; }

    public void setCompleted(boolean completed) { this.completed = completed; }

    // For DiffUtil comparison
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Task)) return false;
        Task task = (Task) obj;
        return id == task.id &&
                completed == task.completed &&
                title.equals(task.title) &&
                description.equals(task.description) &&
                date.equals(task.date) &&
                priority.equals(task.priority);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id, title, description, date, priority, completed);
    }
}
